const zeusmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Mateuzin:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  EDITADO POR *Mateuzin0800*
  DUVIDAS? 👇
  WA.me/5517996562227
╚════════════════════`
}

exports.zeusmenu = zeusmenu








